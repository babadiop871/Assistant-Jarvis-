JARVIS — prototype iPhone

Fichiers :
- index.html : application web
- manifest.json : configuration installable
- sw.js : cache hors ligne basique

Pour tester :
1. Ouvrir index.html dans un navigateur pour tester la maquette (la voix dépend du navigateur).
2. Pour l'ajouter comme vraie web app depuis Safari, les fichiers doivent être publiés sur une URL HTTPS.
3. Dans Safari iPhone : bouton Partager > Sur l'écran d'accueil.

Limites de cette bêta :
- pas encore de modèle IA connecté : réponses locales prédéfinies;
- pas d'appels téléphoniques entrants;
- la voix et la dictée varient selon la version d'iOS/Safari;
- les rappels ne s'exécutent pas de façon fiable en arrière-plan.
